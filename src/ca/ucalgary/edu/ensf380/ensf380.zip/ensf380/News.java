package ca.ucalgary.edu.ensf380;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

class NewsTest {

    @Test
    void testFetchNews() {
        try {
            String[] articles = News.fetchNews("test");
            assertNotNull(articles, "Fetched articles should not be null");
            assertTrue(articles.length > 0, "There should be at least one article");
            
            for (String article : articles) {
                assertTrue(article.contains("Title:"), "Each article should contain a title");
                assertTrue(article.contains("Published At:"), "Each article should contain a publish date");
                assertTrue(article.contains("Description:"), "Each article should contain a description");
                assertTrue(article.contains("URL:"), "Each article should contain a URL");
            }
        } catch (Exception e) {
            fail("Fetching news failed: " + e.getMessage());
        }
    }

    @Test
    void testFetchNewsWithInvalidQuery() {
        assertThrows(Exception.class, () -> News.fetchNews(""), "Should throw exception for empty query");
    }
}
