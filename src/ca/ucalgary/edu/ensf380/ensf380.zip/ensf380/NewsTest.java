package ca.ucalgary.edu.ensf380;

public class NewsTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
